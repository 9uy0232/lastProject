const express=require('express');const bodyParser=require('body-parser');const app=express();const mysql=require('mysql2/promise');const cors=require("cors");app.use(bodyParser.json());app.use(cors());const port=3000;let users=[]
let counter=1;let conn=null;const initMySQL=async()=>{conn=await mysql.createConnection({host:'localhost',user:'root',password:'root',database:'webdb',port:8700,})}
app.get('/sales',async(req,res)=>{const results=await conn.query("SELECT * FROM sales");res.json(results[0])})
app.post('/sales',async(req,res)=>{try{let user=req.body;const results=await conn.query("INSERT INTO sales SET ?",user);res.json({message:"Create new product successfully.",data:results[0]})}catch(error){console.log("errorMessage",error.message);res.status(500).json({message:"Something went wrong",})}})
app.get('/sales/:id',async(req,res)=>{try{let id=req.params.id
const results=await conn.query("SELECT * FROM sales WHERE id = ?",id);if(results[0].length==0){throw{statusCode:404,message:"product not found"}}
res.json(results[0][0])}catch(error){console.log("errorMessage",error.message);let statusCode=error.statusCode||500
res.status(statusCode).json({message:"Somethinh went wrong",errorMessage:error.message,})}})
app.put('/sales/:id',async(req,res)=>{try{let id=req.params.id;let updateUser=req.body;const results=await conn.query("UPDATE sales SET ? WHERE id = ?",[updateUser,id]);res.json({message:"Update product successfully.",data:results[0]})}catch(error){console.log("errorMessage",error.message);res.status(500).json({message:"Something went wrong",})}})
app.delete('/sales/:id',async(req,res)=>{try{let id=req.params.id;const results=await conn.query("DELETE FROM sales WHERE id = ?",id);res.json({message:"Delete product successfully.",data:results[0]})}catch(error){console.log("errorMessage",error.message);res.status(500).json({message:"Something went wrong",})}})
app.listen(port,async(req,res)=>{await initMySQL();console.log('http server running on',+port)})