const BASE_URL='http://localhost:3000';let mode="CREATE";let selectedId="";window.onload=async()=>{const urlParams=new URLSearchParams(window.location.search);const id=urlParams.get("id");if(id){mode="EDIT";selectedId=id;console.log("id",id);try{const response=await axios.get(`${BASE_URL}/sales/${id}`);const user=response.data;let productNameDOM=document.querySelector("input[name=productname]");let priceDOM=document.querySelector("input[name=price]");let remainingDOM=document.querySelector("input[name=remaining]");let dateDOM=document.querySelector("input[name=date]");let timeDOM=document.querySelector("input[name=time]");let productIDDOM=document.querySelector("input[name=productID]");let soldDOM=document.querySelector("input[name=sold]");let clientNameDOM=document.querySelector("input[name=clientname]");let addressDOM=document.querySelector("input[name=address]");let phoneDOM=document.querySelector("input[name=phone]");productNameDOM.value=user.ProductName;priceDOM.value=user.Price;remainingDOM.value=user.Remaining
dateDOM.value=user.Date.split('T')[0];timeDOM.value=user.Time;productIDDOM.value=user.ProductID;soldDOM.value=user.Sold;clientNameDOM.value=user.ClientName;addressDOM.value=user.Address;phoneDOM.value=user.Phone}catch(error){console.log("Error",error)}}}
const validateData=(userData)=>{let errors=[]
if(!userData.productname){errors.push("Please enter Product Name.")}
if(!userData.price){errors.push("Please enter Price.")}
if(!userData.remaining){errors.push("Please enter Remaining.")}
if(!userData.date){errors.push("Please enter Date.")}
if(!userData.time){errors.push("Please enter Time.")}
if(!userData.productID){errors.push("Please enter ProductID.")}
if(!userData.sold){errors.push("Please enter Sold.")}
if(!userData.clientname){errors.push("Please enter Client Name.")}
if(!userData.address){errors.push("Please enter Address.")}
if(!userData.phone){errors.push("Please enter Phone.")}
return errors}
const submitData=async()=>{let productNameDOM=document.querySelector("input[name=productname]");let priceDOM=document.querySelector("input[name=price]");let remainingDOM=document.querySelector("input[name=remaining]");let dateDOM=document.querySelector("input[name=date]");let timeDOM=document.querySelector("input[name=time]");let productIDDOM=document.querySelector("input[name=productID]");let soldDOM=document.querySelector("input[name=sold]");let clientNameDOM=document.querySelector("input[name=clientname]");let addressDOM=document.querySelector("input[name=address]");let phoneDOM=document.querySelector("input[name=phone]");let messageDOM=document.getElementById('message');try{let userData={productname:productNameDOM.value,price:priceDOM.value,remaining:remainingDOM.value-soldDOM.value,date:dateDOM.value,time:timeDOM.value,productID:productIDDOM.value,sold:soldDOM.value,clientname:clientNameDOM.value,address:addressDOM.value,phone:phoneDOM.value,}
console.log("submitData",userData);const errors=validateData(userData);if(errors.length>0){throw{message:"Incomplete data entry.",errors:errors}}
let message="Data saved successfully.";if(mode=="CREATE"){const response=await axios.post(`${BASE_URL}/sales`,userData);console.log('Response',response.data)}else{const response=await axios.put(`${BASE_URL}/sales/${selectedId}`,userData);message="Data edited successfully.";console.log('Response',response.data)}
messageDOM.innerText=message;messageDOM.className="message success"}catch(error){console.log('error message',error.message);console.log("error",error.errors);if(error.response){console.log(error.response.data.message);error.message=error.response.data.message;error.errors=error.response.data.errors}
let htmlData='<div>';htmlData+=`<div><h2>${error.message}</h2></div>`;htmlData+='<ul>';for(let i=0;i<error.errors.length;i++){htmlData+=`<li>${error.errors[i]}</li>`}
htmlData+='</ul>';htmlData+='</div>';messageDOM.innerHTML=htmlData
messageDOM.className="message danger"}}