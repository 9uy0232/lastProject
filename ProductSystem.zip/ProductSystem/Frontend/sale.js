const BASE_URL='http://localhost:3000'
window.onload=async()=>{await loadData()}
const loadData=async()=>{console.log('on load')
const response=await axios.get(`${BASE_URL}/sales`)
console.log(response.data);const userDOM=document.querySelector('#user')
let htmlData='<table>'
htmlData+=`<tr><th>ID</th> <th>Product Name</th> <th>Price</th> <th>Remaining</th> <th>Date</th> <th>Time</th> <th>Product ID</th> <th>Sold</th> <th>Client Name</th> <th>Address</th> <th>Phone</th></tr>`;for(let i=0;i<response.data.length;i++){let user=response.data[i]
htmlData+=`<tr>
        <td data-Label="ID" >${user.id}</td>
        <td data-Label="Product Name" >${user.ProductName}</td>
        <td data-Label="Price" >${user.Price}</td>
        <td data-Label="Remaining" >${user.Remaining}</td>
        <td data-Label="Date" >${user.Date.split('T')[0]}</td>
        <td data-Label="Time" >${user.Time}</td>
        <td data-Label="Product ID" >${user.ProductID}</td>
        <td data-Label="Sold" >${user.Sold}</td>
        <td data-Label="Client Name" >${user.ClientName}</td>
        <td data-Label="Address" >${user.Address}</td>
        <td data-Label="Phone" >${user.Phone}</td>
        <td data-Label="Edit"><a href="index.html?id=${user.id}" ><button>Edit </button></a></td>
        <td data-Label="Delete"><button class='delete' data-id='${user.id}'>Delete </button></td>
    </tr>`}
htmlData+='</table>'
userDOM.innerHTML=htmlData;let deleteBox=document.getElementById('delete-table');const deleteDOM=document.getElementsByClassName('delete');for(let i=0;i<deleteDOM.length;i++){deleteDOM[i].addEventListener('click',async(event)=>{const id=event.target.dataset.id
try{await axios.delete(`${BASE_URL}/sales/${id}`);loadData();deleteBox.textContent=`Delete ID ${id} success.`;deleteBox.className="delete-table deleteSuccess";console.log(`Delete ID ${id} success.`)}catch(error){console.error(error)}})}}