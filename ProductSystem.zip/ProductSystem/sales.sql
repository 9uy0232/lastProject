-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: db:3306
-- Generation Time: Mar 29, 2024 at 01:25 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int NOT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Price` int NOT NULL,
  `Remaining` int NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `ProductID` varchar(255) NOT NULL,
  `Sold` int NOT NULL,
  `ClientName` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `ProductName`, `Price`, `Remaining`, `Date`, `Time`, `ProductID`, `Sold`, `ClientName`, `Address`, `Phone`) VALUES
(1, 'Doggo', 100, 5000, '2024-03-01', '13:50:51', 'P111', 250, 'Somguy', 'Thailand', '0123456789'),
(2, 'Catto', 200, 3000, '2024-03-05', '01:52:28', 'P112', 500, 'JohnDoe', 'USA', '099999999'),
(3, 'Computer', 35000, 5000, '2024-03-29', '19:55:22', 'C151', 3000, 'JohnDoe', 'Japan', '0147258369'),
(4, 'DoggoWater', 25, 40000, '2024-03-13', '23:40:00', 'P115', 4560, 'Renny', 'UK', '0741852963'),
(5, 'CattoToy', 325, 8000, '2024-03-18', '19:59:36', 'P117', 2900, 'Sandy', 'Thailand', '0963852741');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
